from datetime import datetime
import sqlite3


class User:
    def __init__(self, login, password, acc_created="", acc_active="", wrong_pass_counter=0):
        self.login = login
        self.password = password
        self.acc_created = acc_created
        self.acc_active = acc_active
        self.wrong_pass_counter = wrong_pass_counter

        # connect to DB (idk if it safe)
        self.conDB = sqlite3.connect('DB_APC.db')

    # TODO: error catcher
    # TODO: password validator (min 8 chars, numbers, big letters, special chars...)
    def create_account(self):
        cur = self.conDB.cursor()
        db_login_query = []
        for row in cur.execute("SELECT LOGIN FROM Users"):
            db_login_query.append("".join(row))

        if self.login not in db_login_query:
            self.acc_created = datetime.date(datetime.now())
            self.acc_active = 1
            cur.execute("INSERT INTO Users (LOGIN, HASH_PASSWORD, ACC_CREATED, ACC_ACTIVE, COUNTER_FAILED_LOGIN)"
                        "VALUES (?, ?, ?, ?, ?)", (self.login, self.password, self.acc_created, self.acc_active,
                                                self.wrong_pass_counter))
            self.conDB.commit()
            return 1
        else:
            return 0

    # TODO: that function below
    def logged_user_info(self):
        # hash password
        print(f"user: {self.login}, pass: {self.password}")
        pass

    def __incorrect_password(self):
        cur = self.conDB.cursor()

        for row_failed_login in cur.execute("SELECT COUNTER_FAILED_LOGIN FROM Users WHERE LOGIN=?", [self.login]):
            self.wrong_pass_counter = int(row_failed_login[0])+1

        cur.execute("UPDATE Users SET COUNTER_FAILED_LOGIN=? WHERE LOGIN=?", (self.wrong_pass_counter, self.login))
        self.conDB.commit()

        if self.wrong_pass_counter>3:
            cur.execute("UPDATE Users SET ACC_ACTIVE=0 WHERE LOGIN=?", [self.login])
            self.conDB.commit()

        print("Złe hasło lub login!")

    def login_to_app(self):
        # first compare login from db query
        # if exist -> check password
        # if correct -> check if account is not disable

        cur = self.conDB.cursor()
        db_login_query = []
        db_pass_query = []

        # check if login is OK
        for row_log in cur.execute("SELECT LOGIN FROM Users"):
            db_login_query.append("".join(row_log))
        if self.login not in db_login_query:
            print(f"nie ma takiego usera lub haslo jest niepoprawne - {self.login}")
            return 1

        # check if password is OK
        for row_pass in cur.execute("SELECT HASH_PASSWORD FROM Users WHERE LOGIN=?", [self.login]):
            db_pass_query.append("".join(row_pass))
        if self.password not in db_pass_query:
            self.__incorrect_password()
            return 2

        # check if account is not blocked
        for row_isActive in cur.execute("SELECT ACC_ACTIVE FROM Users WHERE LOGIN=?", [self.login]):
            if row_isActive[0] != 1:
                print(f"Account {self.login} is blocked! Contact ur administrator")
                return 3

        print("login success")
        return 0

    def delete_account(self):
        cur = self.conDB.cursor()
        cur.execute("DELETE FROM Users WHERE LOGIN=?", [self.login])
        self.conDB.commit()
        print("profile deleted")
        return 1

    # TODO: implementation in ADMIN panel
    def enable_account(self):
        try:
            cur = self.conDB.cursor()
            cur.execute("UPDATE Users SET ACC_ACTIVE=1 WHERE LOGIN=?", [self.login])
            self.conDB.commit()
            return 1

        except ValueError:
            print("Error")
            return 0

    def change_login(self, new_login):
        cur = self.conDB.cursor()
        cur.execute("UPDATE Users SET LOGIN=? WHERE LOGIN=?", (new_login, self.login))
        self.conDB.commit()

    def change_password(self, new_password):
        cur = self.conDB.cursor()
        cur.execute("UPDATE Users SET HASH_PASSWORD=? WHERE LOGIN=?", (new_password, self.login))
        self.conDB.commit()

    def get_id(self):
        cur = self.conDB.cursor()
        user_id = ""
        for user in cur.execute("SELECT ID FROM Users WHERE LOGIN=?", [self.login]):
            user_id = user

        return user_id[0]

    def __del__(self):
        self.conDB.close()
