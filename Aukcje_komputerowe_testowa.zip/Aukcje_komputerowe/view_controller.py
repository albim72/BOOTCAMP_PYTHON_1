from functions import sell_item, show_my_item, end_auction, delete_auction, view_item, call_item, buy_item


def login_view(user):
    bool_logged_user = True
    while bool_logged_user:
        try:
            menu = int(input("wybierz opcje: "
                             "\n1 - Mój profil"
                             "\n2 - Zobacz aukcje"
                             "\n3 - Wystaw sprzęt komputerowy"
                             "\n4 - Zobacz moje wystawione przedmioty"
                             "\n5 - Wyloguj się\n"))

            # [+] moj profil
            if menu == 1:
                # Umozliwia wejscie w interfejs, ktory zmienia login/haslo
                # Po zmianie nastepuje wylogowanie
                menu_profile = int(
                    input("Profil użytkownika, wybierz akcję:"
                          "\n1 - Zmiana loginu "
                          "\n2 - Zmiana hasła"
                          "\n3 - Wyjście\n"))

                if menu_profile == 1:
                    new_login = input("Wprowadź nowy login:\n")
                    user.change_login(new_login)
                    bool_logged_user = False

                elif menu_profile == 2:
                    new_password = input("Wprowadź nowe hasło:\n")
                    user.change_password(new_password)
                    bool_logged_user = False

                elif menu_profile == 3:
                    pass

            # [-] zobacz aukcje
            elif menu == 2:
                auction_view(user)

            # [+] wystaw aukcje
            elif menu == 3:
                sell_item(user)

            # [+] zobacz moje przedmioty
            elif menu == 4:
                my_auctions(user)

            # [+] wyloguj sie
            elif menu == 5:
                bool_logged_user = False

        except ValueError:
            pass


def auction_view(user):
    running = True
    item_index = 0

    while running:
        id_item = view_item(user, item_index)

        try:
            menu_my_auctions = int(input("Wybierz akcję:"
                                         "\n1 - Kup"
                                         "\n2 - Zalicytuj"
                                         "\n3 - Następna aukcja"
                                         "\n4 - Wyjdź\n"))

            if menu_my_auctions == 1:
                buy_item(user, id_item)

            elif menu_my_auctions == 2:
                call_item(user, id_item)

            elif menu_my_auctions == 3:
                if id_item != 0:
                    item_index += 1
                else:
                    item_index = 0
                    print("To byl ostatni przedmiot")

            elif menu_my_auctions == 4:
                running = False

        except ValueError:
            pass


def my_auctions(user):
    running = True
    item_index = 0
    while running:
        id_item = show_my_item(user, item_index)

        try:
            menu_my_auctions = int(input("Wybierz akcję:"
                                         "\n1 - Zakończ aukcje"
                                         "\n2 - Usuń aukcję"
                                         "\n3 - Następna moja aukcja"
                                         "\n4 - Wyjście\n"))
            # zakończ aukcje
            if menu_my_auctions == 1:
                end_auction(user, id_item)

            # usun aukcje
            elif menu_my_auctions == 2:
                delete_auction(user, id_item)

            # następna moja aukcja
            elif menu_my_auctions == 3:
                if id_item != 0:
                    item_index += 1
                else:
                    item_index = 0
                    print("To byl ostatni wystawiony przedmiot")

            # wyjscie
            elif menu_my_auctions == 4:
                running = False

        except ValueError:
            pass