import sqlite3
import os

from User import User
from view_controller import login_view


# source:
# https://realpython.com/python-gui-tkinter/
# https://docs.python.org/3/library/sqlite3.html

def cls():
    os.system('cls')


# function testing
running = True
while running:

    print("Aplikacja Aukcje komputerowe: proszę się zalogować lub zarejestrowac"
          "\n1 - Zaloguj się "
          "\n2 - Zarejestruj się"
          "\n3 - Wyjdź z programu")

    try:
        menu = int(input("choose option:\n"))

        cls()

        # logowanie: jeśli user jest zalogowany, to ma dostep do innych funkcji
        if menu == 1:
            login = input("login: ")
            password = input("password: ")

            cls()

            user = User(login, password)
            login_result = user.login_to_app()
            if login_result == 0:
                login_view(user)

            elif login_result == 1:
                pass
            elif login_result == 3:
                pass
            elif login_result == 2:
                pass

        # rejestracja: po udanej rejestracji user musi się zalogować
        elif menu == 2:
            login = input("login: ")
            password = input("password: ")
            user = User(login, password)

            if user.create_account() == 1:
                print("created!")
            else:
                print("cant create account, duplicate login")

        # wyjscie z programu
        elif menu == 3:
            running = False

        # opcje administratora
        elif menu == 44:
            adm_menu = int(input("OPCJE ADMINISTRATORA: "
                                 "\n1 - ODBLOKUJ UŻYTKOWANIKA"
                                 "\n2 - WYJDZ\n"))
            if adm_menu == 1:
                locked_accounts = []
                # connect with database
                conDB = sqlite3.connect('DB_APC.db')
                query = "SELECT LOGIN " \
                        "FROM Users " \
                        "WHERE ACC_ACTIVE = 0"

                cur = conDB.cursor()

                for row_log in cur.execute(query):
                    locked_accounts.append("".join(row_log))

                locked_accounts.sort()
                for array_login_index in range(len(locked_accounts)):
                    print(array_login_index, ": ", locked_accounts[array_login_index])

                unlock_account = input("WPISZ NAZWE UZYTKOWNIKA, KTÓREGO CHCESZ ODBLOKOWAĆ:\n")

                if unlock_account in locked_accounts:
                    cur.execute("UPDATE Users "
                                "SET COUNTER_FAILED_LOGIN=0, ACC_ACTIVE = 1 "
                                "WHERE LOGIN=?", [unlock_account])

                    conDB.commit()
                else:
                    cls()
                    print("PODANO ZŁY LOGIN \n")

                conDB.close()

            elif adm_menu == 2:
                pass
    except ValueError:
        pass
