"""
Definition of urls for people.
"""

from datetime import datetime
from django.urls import path
from django.contrib import admin
from django.contrib.auth.views import LoginView, LogoutView
from app import forms, views
from app.views import PersonCreateView,PersonListView,PersonUpdateView



urlpatterns = [
    path('',PersonListView.as_view(), name='person_list'),
    path('add/',PersonCreateView.as_view(),name="person_add"),
    path('<int:pk>/edit/',PersonUpdateView.as_view(),name="person_edit"),
]
