"""
Package for people.
"""
