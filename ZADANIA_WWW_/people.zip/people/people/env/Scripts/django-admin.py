#!C:\BOOTCAMP_PYTHON_PROJEKTY\STRONY_WWW\PROJEKTY_DJANGO\people\people\env\Scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
