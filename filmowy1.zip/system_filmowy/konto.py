from user import Uzytkownik

class Konto(Uzytkownik):
    pass

