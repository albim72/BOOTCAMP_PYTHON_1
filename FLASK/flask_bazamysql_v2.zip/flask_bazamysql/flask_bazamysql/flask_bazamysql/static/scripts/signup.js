$(function () {
    $('#btnSingUp').click(function () {
        $.ajax({
            url: '/signup',
            data: $('form').serialize(),
            type: 'POST',
            success: function (reponse) {
                console.log(response)
            },
            error: function (error) {
                console.log(error)
            }
        });
    });
});