"""
Routes and views for the flask application.
"""

from datetime import datetime
import re
from flask import render_template,request,json
from flaskext.mysql import MySQL
from flask_bazamysql import app

@app.route('/')
@app.route('/home')
def home():
    """Renders the home page."""
    return render_template(
        'index.html',
        title='Home Page',
        year=datetime.now().year,
    )

@app.route('/showsignup')
def showsignup():
    return render_template('signup.html')

@app.route('/signup', methods = ['POST','GET'])
def signup():
    try:
        _name = request.form['inputName']
        _email = request.form['inputEmail']
        _password = request.form['inputPassword']

        if _name and _email and _password:
            return json.dumps({'html':'<span>Wszystkie pola wypelnione!</span>'})
        else:
            return json.dumps({'html':'<span>Wypelnij wszystkie pola!</span>'})


    except Exception as e:
        return json.dumps({'error':str(e)})
    

