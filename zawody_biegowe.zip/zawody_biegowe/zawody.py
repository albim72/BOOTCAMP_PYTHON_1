class Zawody:

    def __init__(self,idzawodow,nazwa,dlugosc_trasy,miejsce,limit_czasowy,liczba_zawodnikow):
        self.idzawodow = idzawodow
        self.nazwa = nazwa
        self.dlugosc_trasy = dlugosc_trasy
        self.miejsce = miejsce
        self.limit_czasowy = limit_czasowy
        self.liczba_zawodnikow = liczba_zawodnikow


    @property
    def dlugosc_trasy(self):
        return self._dlugosc_trasy

    @property
    def limit_czasowy(self):
        return self._limit_czasowy

    @dlugosc_trasy.setter
    def dlugosc_trasy(self,dlugosc_trasy):
        self._dlugosc_trasy = dlugosc_trasy

    @limit_czasowy.setter
    def limit_czasowy(self,limit_czasowy):
        self._limit_czasowy = limit_czasowy


    def print_zawody(self):
        return f"nazwa zawodów: {self.nazwa}, długość trasy: {self.dlugosc_trasy} km, " \
               f"limit czasowy: {self.limit_czasowy} min"

