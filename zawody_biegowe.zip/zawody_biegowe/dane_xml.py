import xml.sax

class CompetitionHandler(xml.sax.ContentHandler):

    def __init__(self):
         self.current_data=""
         self.imie=""
         self.nazwisko=""
         self.miasto=""
         self.nrstartowy = ""
         self.nazwa_zawodow = ""
         self.dlugosc_trasy=""
         self.dane = ""

    def startElement(self,tag,attributes):
        self.current_data = tag
        if tag == "zarejestrowany_zawodnik":
            self.dane = "************* zawodnik ****************"

    def endElement(self,tag):

        if self.current_data == "imie":
            self.dane +=  f"imię zawodnika: {self.imie}\n"
        elif self.current_data == "nazwisko":
            self.dane += f"nazwisko zawodnika: {self.nazwisko}"
        elif self.current_data == "miasto":
            self.dane += f"miasto pochodzenia zawodnika: {self.miasto}"
        elif self.current_data == "nr_startowy":
            self.dane += f"numer startowy zawodnika: {self.nrstartowy}"
        elif self.current_data == "nazwa":
            self.dane += f"nazwa zawodów: {self.nazwa_zawodow}"
        elif self.current_data == "dlugosc_trasy":
            self.dane += f"długość trasy: {self.dlugosc_trasy} km"
            print(self.dane)
    def characters(self,content):
        if self.current_data == "imie":
            self.imie = content
        elif self.current_data == "nazwisko":
            self.nazwisko = content
        elif self.current_data == "miasto":
            self.miasto = content
        elif self.current_data == "nr_startowy":
            self.nrstartowy = content
        elif self.current_data == "nazwa":
            self.nazwa_zawodow = content
        elif self.current_data == "dlugosc_trasy":
            self.dlugosc_trasy = content