import xml.sax
from rejestracja import Rejestracja,Biegacz,Zawody
from dane_xml import CompetitionHandler


b1 = Biegacz(89,"Leon","Nowak",30,"Tarnów","877665544",78,175,"m")

print(b1.printdane())

z1 = Zawody(456,"Tatra Sky Marathon",42,"Zakopane",600,350)
print(z1.print_zawody())

b1.miasto = "Rzeszów"
print(b1.printdane())

rej1 = Rejestracja(6,"Olga","Kot",26,"Kraków","677888999",54,170,"k",234,390,"7:00",2,"Tatra Sky Marathon",
                   42,"Zakopane",600,350)

print(rej1.printrejstracja())

parser = xml.sax.make_parser()
parser.setFeature(xml.sax.handler.feature_namespaces,0)

hand = CompetitionHandler()

parser.setContentHandler(hand)
parser.parse("rejestracja.xml")
rtfstr = hand.dane


#zapisz w pliku rtf zparsowane dane zwodników

f = open("rejestracja.rtf","w",encoding="utf-8")
f.write(rtfstr)

f.close()