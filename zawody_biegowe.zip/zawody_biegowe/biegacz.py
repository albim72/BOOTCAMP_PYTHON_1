class Biegacz:

    def __init__(self,id,imie,nazwisko,wiek,miasto,telefon,waga,wzrost,plec):
        self.id = id
        self.imie = imie
        self.nazwisko = nazwisko
        self.wiek = wiek
        self.miasto = miasto
        self.telefon = telefon
        self.waga = waga
        self.wzrost = wzrost
        self.plec = plec

    @property
    def miasto(self):
        return self._miasto
    @property
    def telefon(self):
        return self._telefon
    @miasto.setter
    def miasto(self,miasto):
        self._miasto = miasto
    @telefon.setter
    def telefon(self,telefon):
        self._telefon = telefon
    def printdane(self):
        return f"imię: {self.imie}, nazwisko: {self.nazwisko}, miasto: {self.miasto}, telefon: {self.telefon}"