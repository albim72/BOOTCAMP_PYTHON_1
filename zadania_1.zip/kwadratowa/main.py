import math

#y = ax**2+bx+c
#ax**2+bx+c = 0
def f_kwadratowa(a,b,c):
    if a==0:
        print("to nie jest równanie kwardratowe, to jest równanie liniowe")
        # bx+c=0
        # bx=-c
        x=-c/b
        print(f"wynik, x = {x}")

    else:
        delta = b**2 - 4*a*c
        if delta < 0:
            print("równanie nie ma pierwiastków")
        elif delta == 0:
            x0 = -b/(2*a)
            print(f"jedno rozwiązanie x = {x0}")
        else:
            x1=(-b-math.sqrt(delta))/(2*a)
            x2=(-b+math.sqrt(delta))/(2*a)
            print(f"dwa rozwiązania x1 = {x1}, x2 = {x2}")


a = float(input("podaj wartość a: "))
b = float(input("podaj wartośc b: "))
c = float(input("podaj wartośc c: "))

f_kwadratowa(a,b,c)