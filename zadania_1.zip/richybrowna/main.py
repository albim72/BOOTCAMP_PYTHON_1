def ruchy_browna(pozycja_poczatkowa: tuple, ile_krokow:int, wektor_r:float, seed_start:int):
    from math import sqrt, sin, cos, pi, radians
    from random import randint, seed
    seed(seed_start)
    brown_X: list = [pozycja_poczatkowa[0]]
    brown_Y: list = [pozycja_poczatkowa[1]]
    for krok in range(1, ile_krokow):
    # wylosowany kąt musi być podany w radianach; wymagają t
        fi: float = radians(float(randint(0, 360)))
        brown_X.append(brown_X[krok - 1] + (wektor_r * cos(fi)))
        brown_Y.append(brown_Y[krok - 1] + (wektor_r * sin(fi)))
    return (brown_X, brown_Y)
# przykład uruchomienia
punkty = ruchy_browna((0, 0), 10, 0.84,1)
print(punkty[0])
print(punkty[1])