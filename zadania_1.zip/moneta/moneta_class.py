import random
import time


class RzutMoneta:

    def __init__(self,x):
        self.x = x


    def gra(self):
        user = 0
        computer = 0

        while True:

            # wczytujemy wybór uzytkownika

            if self.x == '0':
                break
            elif self.x == 'o':
                self.x = "orzeł"
            elif self.x == 'r':
                self.x = "reszka"
            else:
                print("Proszę dokonać prawidłowego wyboru:")
                print("o - orzeł")
                print("r - reszka")
                print("0 - zakończenie gry")

                # jezeli użytkownik nie wybrał ani, o, r, 0, to wróć do początku wykonywania pętli
                continue
            # rzucamy monetą
            y = random.choice(["orzeł", "reszka"])

            # Odliczamy 3,2,1
            for i in range(0, 3):
                print(3 - i)
                time.sleep(1)

            print("Wynik rzutu: ", y)

            # sprawdzamy kto wygrał
            if self.x == y:
                user += 1
            else:
                computer += 1

            # Drukujemy podsumowanie
            print("Wyniki łacznie.")
            print("Użytkownik: ", user)
            print("Komputer: ", computer)

x = input("podaj wartość - o (orzeł) lub r (reszka): ").lower( )
rzut = RzutMoneta(x)
rzut.gra()
